#!/bin/sh
set -eu
unset LD_LIBRARY_PATH LD_PRELOAD PYTHONHOME PYTHONPATH PYTHONUSERBASE PYTHONSTARTUP PYTHONEXECUTABLE BASH_ENV ENV CDPATH MAKEFLAGS GNUMAKEFLAGS MAKEFILES MFLAGS
b=${0%/*}
[ "$b" != "$0" ] || b=.
R=$(CDPATH= cd -- "$b" && pwd)
exec "$R/runtime/bin/python3" "$R/portable_verify.py" "$@"
