# v23 actual Windows netlist proof kit

This separate package replays the preserved **eighteen actual Windows v23 post-ABC RTLIL objects**, plus the mandatory wrong-output negative control. It does not rebuild/re-measure Windows Yosys or replace the original Windows ZIP. The original frozen formal helpers, RTL, raw Windows report/manifest and raw RTLIL bytes are retained.

Platform: **Linux x86_64**, including a compatible WSL2 Linux distribution, a mounted `/proc`, `/dev/null`, `/bin/sh` for launching the relative entry, and writable temporary/output storage. CPython 3.10, its stdlib/extension-library closure, Click, original Yosys 0.69/ABC/share, EQY 0.69 plugins/modules, SBY 0.68, witness utility, GNU make/shell/text utilities, private ELF loader and shared libraries are included. No external Ubuntu repository, absolute historical tool manifest, OSS CAD Suite installation, Python site-packages, SMT solver or network service is required by the SAT/ABC-PDR proof strategy. This is **not native Windows EQY**. Portability remains subject to the Linux kernel/architecture boundary and the recorded relocation test.

Extract to a **new ASCII directory without spaces**, e.g. `/tmp/fpga-proof-v23-replay`. Keep the executable mode bits (use the `.tar.gz` distribution on Linux).

```sh
./run_verify.sh --preflight-only
./run_verify.sh
```

Every run creates a new `results/replay-*` directory. Success requires all 18 positive EQY proofs plus a definite counterexample for the intentional wrong-output control. Inspect `formal/report.json` and `portable-replay-receipt.json`. The initial copy operation and a preflight/version PASS are not a proof PASS.

`portable-index.json` binds the payload. `provenance/closure.json` lists sources, versions, dependency checks and file hashes; `licenses/` retains collected license notices. The runtime tool manifest is generated after relocation and all active proof paths refer inside this kit. The Linux `candidate` entry is explicitly an original-baseline parser alias: the optimized candidate being proved is the already-generated Windows RTLIL, not a newly synthesized Linux candidate.

Windows area/performance conclusions remain in the original measurements. Formal replay does not change them, establish performance on another machine, or guarantee future cases/onsite acceptance. Historical absolute Windows paths in preserved raw reports are metadata, not runtime dependencies.
