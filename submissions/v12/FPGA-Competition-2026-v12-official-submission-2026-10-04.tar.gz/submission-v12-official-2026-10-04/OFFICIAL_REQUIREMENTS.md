# 赛题二官方答疑约束与本版本对应关系

来源：`/home/jumptiger/Downloads/FPGA创新大赛问题汇总0.xlsx`，工作表
`Sheet1`。这里只把“解答”列作为官方约束；“问题详情”列仅用于理解上下文。
当早期答复与后期答复冲突时，采用后期、更具体的答复。

| 官方约束 | 工作表位置 | v12 实现或检查 |
|---|---|---|
| 正式评测只使用已公布的 4 个 case | `C4`, `C42` | `work/local_reproduce_v12.py` 固定运行 `test1` 到 `test4` |
| 统一使用 Yosys 0.69 | `C37` | 源码固定到提交 `9f75ca1f9834a39a863915b5dae0c7b1e33533bc` |
| 优化必须编译成内置 pass，不能使用插件 `.so` | `C24`, `C37` | `pmux_competition_opt` 注册在 `passes/opt/CMakeLists.txt` |
| pass 调用必须放进 `synth_intel.cc`，原版和优化版外部脚本相同 | `C37`, `C53` | pass 在 `synth_intel` 的 `coarse` 阶段调用；复现报告保存并核对两边同内容的 `flow.ys` |
| 映射统一使用 `synth_intel -family cycloneiv` | `C8:C10`, `C54` | 资源统计流程严格使用该命令 |
| 映射器必须是 Yosys 自带的 `abc9`；允许调 ABC 脚本，并需随源码提交 | `C23:C24`, `C53`, `C55` | 调用 `abc9 -lut 4 -W 300 -script +/intel/competition_abc_v12.abc`；没有换成 `abc` |
| 主要指标是 LUT；按四个用例各自缩减率的平均值计分 | `C21`, `C25`, `C53` | 报告逐例统计 `cycloneiv_lcell_comb`，再计算算术平均 |
| DFF、IO 等其他单元原则上不能增加 | `C21`, `C25`, `C53` | 逐例检查 DFF、IO，以及每一种非 LUT 单元类型均不增加 |
| CPU 时间包含 ABC，并且每个用例单独满足效率要求 | `C26`, `C42` | CPU 使用子进程资源累计值；基线与候选交错运行 5 次并报告中位数和全部样本 |
| 峰值工作内存只看 `yosys.exe` | `C54` | 只轮询直接 Yosys 进程的 `/proc/<pid>/status` 中 `VmRSS`，不把 ABC 子进程 RSS 算入 |
| 等价验证对象是原 RTL 与 ABC 后的 `$lut` ILANG；允许整设计 miter 模式 | `C53:C54` | 用 `-run begin:map_cells` 在技术单元映射前输出 `post_abc.il`，再进行整设计时序等价证明 |
| 提交优化源码、修改后的 ABC 脚本、Yosys 可执行文件及依赖 | `C55` | 独立目录保留源码、脚本、补丁、`build/yosys` 与 `build/yosys-abc` |

## 口径说明

“必须用 Yosys 自带的 abc9”限制的是映射器，不能把流程改成旧的 `abc`。
官方同时明确允许调整 ABC 脚本并要求随提交物一起提供，因此本版本仍然是
Yosys 内置 `abc9`，只是通过它的 `-script` 参数加载随源码构建安装的调优脚本。

本地效率数字采用 5 次交错运行的中位数来抑制短用例的调度和页驻留抖动。
报告同时保留每一次原始样本；正式成绩仍以组委会评测环境和计量实现为准。
