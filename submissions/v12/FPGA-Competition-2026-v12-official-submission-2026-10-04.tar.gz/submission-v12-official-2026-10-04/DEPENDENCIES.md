# Runtime and build dependencies

Validated host: Ubuntu x86-64, GNU C++ 11.4.0.

## Runtime submission set

Keep these paths together so Yosys can find its data files and ABC executable:

- `yosys`
- `yosys-abc`
- `share/` (includes `intel/competition_abc_v12.abc`)
- `lib/` (redistributable GCC/zlib runtime libraries used by `run-yosys.sh`)

Dynamic libraries reported by `ldd yosys`:

- `libz.so.1`
- `libstdc++.so.6`
- `libm.so.6`
- `libgcc_s.so.1`
- `libc.so.6`
- the platform ELF loader (`ld-linux-x86-64.so.2`)

`yosys-abc` requires `libstdc++.so.6`, `libm.so.6`, `libgcc_s.so.1`, `libc.so.6`,
and the ELF loader. The package supplies compatible `libstdc++`, `libgcc_s`, and
`libz` copies. glibc, `libm`, and the ELF loader deliberately come from the
evaluation host to avoid bundling a host-specific glibc.

## Rebuild

From the package root, perform a clean out-of-tree build with:

```bash
./tools/build_from_source.sh
```

For a clean machine, install a C++ compiler, CMake 3.28 or newer, Make, Bison,
Flex, Python 3, pkg-config, and zlib development headers. The supplied build
script disables optional Tcl, readline, libffi, Python embedding, and slang
features; they are not needed by this submission.

To validate a rebuilt binary against the packaged four-case smoke test:

```bash
YOSYS_RUNNER="$PWD/rebuild/yosys" python3 tools/smoke_test.py
```
