# PMUX competition v12 (official-Q&A aligned isolated copy)

This directory is an isolated optimization copy. The original repository and
the validated v11 files under `FPGA-Competition-2026/clean-v11` are not
overwritten.

## Optimization change

`pmux_competition_v12.cc` keeps the v11 decoder-constant propagation and
adds selector-order search for each complete equality-decoded PMUX group. It
constructs a shared bit-level Shannon DAG for every selector permutation and
commits the smallest graph only when it does not exceed the existing LUT
estimate. The transformation remains limited to non-`keep` PMUX cells and
does not alter sequential cells.

The integrated Yosys source is in `yosys-src/`. The standalone candidate is
`build/yosys`.

The Intel flow uses Yosys's built-in ABC9 mapper with a bundled tuned script:

```text
abc9 -lut 4 -W 300 -script +/intel/competition_abc_v12.abc
```

This does not replace `abc9` with `abc`. The spreadsheet answers explicitly
require the built-in `abc9`, while also allowing ABC-script tuning and requiring
the changed script to be submitted. The script is installed as Yosys data by
`techlibs/intel/CMakeLists.txt`.

The authoritative constraint-to-code map is in `OFFICIAL_REQUIREMENTS.md`.

## Layout

- `pmux_competition_v12.cc`: standalone copy of the optimization pass source.
- `yosys-src/`: complete Yosys 0.69 source tree with the pass and ABC9 script integrated.
- `build/yosys`: compiled optimized Yosys executable.
- `build/yosys-abc`: ABC executable invoked by Yosys's `abc9` pass.
- `DEPENDENCIES.md`: runtime submission set and rebuild dependency inventory.
- `work/local_reproduce_v12.py`: four-case synthesis, resource, efficiency, and formal checks.
- `v12-competition.patch`: source patch relative to pristine Yosys 0.69.

## Reproduce

```bash
python3 work/local_reproduce_v12.py
```

The runner uses identical external `synth_intel -family cycloneiv` scripts for
the original and optimized binaries. It counts the final Cyclone IV netlist,
then separately stops before `map_cells` to prove the RTL equivalent to the
post-ABC `$lut` ILANG design. CPU includes ABC CPU; peak memory samples only the
direct Yosys process. Short-case efficiency uses the median of five interleaved
baseline/candidate runs and retains every raw sample.

Latest verified result:

| case | LUT | DFF | IO | proof |
|---|---:|---:|---:|---|
| test1 | 286 -> 221 | 222 -> 222 | 0 -> 0 | PASS / PASS |
| test2 | 25 -> 15 | 0 -> 0 | 0 -> 0 | PASS / PASS |
| test3 | 12 -> 12 | 17 -> 12 | 0 -> 0 | PASS / PASS |
| test4 | 35 -> 26 | 10 -> 10 | 0 -> 0 | PASS / PASS |

Average per-case LUT reduction: **22.11038961038961%**. Every non-LUT cell
type is non-increasing. In the latest five-run median, CPU and Yosys RSS
overhead are within 5% for all four cases.

The detailed report is
`local-reproduction-v12-_k52848w/report.json`.
