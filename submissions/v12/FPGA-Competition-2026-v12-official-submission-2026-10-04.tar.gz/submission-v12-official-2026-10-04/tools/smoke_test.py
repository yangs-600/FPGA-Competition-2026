#!/usr/bin/env python3
import json
import os
import subprocess
import tempfile
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
YOSYS = Path(os.environ.get("YOSYS_RUNNER", ROOT / "run-yosys.sh"))
EXPECTED = {
    "test1": {"lut": 221, "dff": 222, "io": 0},
    "test2": {"lut": 15, "dff": 0, "io": 0},
    "test3": {"lut": 12, "dff": 12, "io": 0},
    "test4": {"lut": 26, "dff": 10, "io": 0},
}


def main():
    version = subprocess.run(
        [str(YOSYS), "-V"], check=True, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    ).stdout.strip()
    if "Yosys 0.69" not in version:
        raise SystemExit(f"unexpected version: {version}")
    print(version)

    with tempfile.TemporaryDirectory(prefix="fpga-v12-smoke-") as temp_name:
        temp = Path(temp_name)
        for top, expected in EXPECTED.items():
            source = ROOT / "validation" / "cases" / top / f"{top}.v"
            netlist = temp / f"{top}.json"
            script = temp / f"{top}.ys"
            script.write_text("\n".join([
                f'read_verilog "{source}"',
                f"synth_intel -family cycloneiv -top {top}",
                f'write_json "{netlist}"',
                "",
            ]))
            log = subprocess.run(
                [str(YOSYS), "-Q", "-T", "-s", str(script)],
                check=True, text=True, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
            ).stdout
            if "Executing PMUX_COMPETITION_OPT v12" not in log:
                raise SystemExit(f"{top}: built-in optimization pass did not run")
            cells = json.loads(netlist.read_text())["modules"][top]["cells"]
            by_type = Counter(cell["type"] for cell in cells.values())
            actual = {
                "lut": by_type["cycloneiv_lcell_comb"],
                "dff": by_type["dffeas"],
                "io": by_type["cycloneiv_io_ibuf"] + by_type["cycloneiv_io_obuf"],
            }
            if actual != expected:
                raise SystemExit(f"{top}: expected {expected}, got {actual}")
            print(f"{top}: LUT={actual['lut']} DFF={actual['dff']} IO={actual['io']} PASS")

    print("submission smoke test: PASS")


if __name__ == "__main__":
    main()
