#!/bin/sh
set -eu

submission_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
jobs=${JOBS:-2}
build_dir=${BUILD_DIR:-"$submission_root/rebuild"}
cmake_bin=${CMAKE:-cmake}

"$cmake_bin" -S "$submission_root/source/yosys-0.69" \
      -B "$build_dir" \
      -DCMAKE_BUILD_TYPE=Release \
      -DYOSYS_COMPONENTS=everything \
      -DYOSYS_ENABLE_UNIT_TESTS=OFF \
      -DYOSYS_ENABLE_FUNCTIONAL_TESTS=OFF \
      -DYOSYS_USE_BUNDLED_LIBS=ON \
      -DYOSYS_WITHOUT_ABC=OFF \
      -DYOSYS_WITHOUT_LIBFFI=ON \
      -DYOSYS_WITHOUT_READLINE=ON \
      -DYOSYS_WITHOUT_SLANG=ON \
      -DYOSYS_WITHOUT_TCL=ON \
      -DYOSYS_WITH_PYTHON=OFF
"$cmake_bin" --build "$build_dir" -j"$jobs"
