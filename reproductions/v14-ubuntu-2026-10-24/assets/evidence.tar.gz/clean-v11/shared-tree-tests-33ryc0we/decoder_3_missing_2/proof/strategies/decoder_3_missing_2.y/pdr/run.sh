STATUS=ERROR
sby -f decoder_3_missing_2.y.sby > /dev/null && STATUS=$(awk '{print $1}' decoder_3_missing_2.y/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'decoder_3_missing_2.y' using strategy 'pdr'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'decoder_3_missing_2.y' using strategy 'pdr': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'decoder_3_missing_2.y' using strategy 'pdr': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'decoder_3_missing_2.y' using strategy 'pdr': timeout"
    ;;
    *)
        cat decoder_3_missing_2.y/ERROR 2> /dev/null
        echo "Execution of strategy 'pdr' on partition 'decoder_3_missing_2.y' encountered an error."
        echo "More details can be found in '/home/jumptiger/Documents/Codex/2026-10-02/FPGA-Competition-2026-repro-v14/clean-v11/shared-tree-tests-33ryc0we/decoder_3_missing_2/proof/strategies/decoder_3_missing_2.y/pdr/decoder_3_missing_2.y/logfile.txt'."
        exit 1
    ;;
esac
exit 0

