STATUS=ERROR
sby -f decoder_4_missing_0.z.sby > /dev/null && STATUS=$(awk '{print $1}' decoder_4_missing_0.z/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'decoder_4_missing_0.z' using strategy 'pdr'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'decoder_4_missing_0.z' using strategy 'pdr': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'decoder_4_missing_0.z' using strategy 'pdr': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'decoder_4_missing_0.z' using strategy 'pdr': timeout"
    ;;
    *)
        cat decoder_4_missing_0.z/ERROR 2> /dev/null
        echo "Execution of strategy 'pdr' on partition 'decoder_4_missing_0.z' encountered an error."
        echo "More details can be found in '/home/jumptiger/Documents/Codex/2026-10-02/FPGA-Competition-2026-repro-v14/clean-v11/shared-tree-tests-33ryc0we/decoder_4_missing_0/proof/strategies/decoder_4_missing_0.z/pdr/decoder_4_missing_0.z/logfile.txt'."
        exit 1
    ;;
esac
exit 0

