STATUS=ERROR
sby -f selector_order_3.y.sby > /dev/null && STATUS=$(awk '{print $1}' selector_order_3.y/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'selector_order_3.y' using strategy 'pdr'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'selector_order_3.y' using strategy 'pdr': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'selector_order_3.y' using strategy 'pdr': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'selector_order_3.y' using strategy 'pdr': timeout"
    ;;
    *)
        cat selector_order_3.y/ERROR 2> /dev/null
        echo "Execution of strategy 'pdr' on partition 'selector_order_3.y' encountered an error."
        echo "More details can be found in '/home/jumptiger/Documents/Codex/2026-10-02/FPGA-Competition-2026-repro-v14/clean-v11/shared-tree-tests-33ryc0we/selector_order_3/proof/strategies/selector_order_3.y/pdr/selector_order_3.y/logfile.txt'."
        exit 1
    ;;
esac
exit 0

