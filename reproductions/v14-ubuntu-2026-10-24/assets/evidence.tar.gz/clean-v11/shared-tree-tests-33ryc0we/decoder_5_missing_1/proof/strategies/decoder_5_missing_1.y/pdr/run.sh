STATUS=ERROR
sby -f decoder_5_missing_1.y.sby > /dev/null && STATUS=$(awk '{print $1}' decoder_5_missing_1.y/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'decoder_5_missing_1.y' using strategy 'pdr'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'decoder_5_missing_1.y' using strategy 'pdr': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'decoder_5_missing_1.y' using strategy 'pdr': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'decoder_5_missing_1.y' using strategy 'pdr': timeout"
    ;;
    *)
        cat decoder_5_missing_1.y/ERROR 2> /dev/null
        echo "Execution of strategy 'pdr' on partition 'decoder_5_missing_1.y' encountered an error."
        echo "More details can be found in '/home/jumptiger/Documents/Codex/2026-10-02/FPGA-Competition-2026-repro-v14/clean-v11/shared-tree-tests-33ryc0we/decoder_5_missing_1/proof/strategies/decoder_5_missing_1.y/pdr/decoder_5_missing_1.y/logfile.txt'."
        exit 1
    ;;
esac
exit 0

