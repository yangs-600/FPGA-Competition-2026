STATUS=ERROR
sby -f sparse_default_4.y.sby > /dev/null && STATUS=$(awk '{print $1}' sparse_default_4.y/status)
echo $STATUS > status
case $STATUS in
    PASS)
        echo "Proved equivalence of partition 'sparse_default_4.y' using strategy 'pdr'"
    ;;
    FAIL)
        echo "Could not prove equivalence of partition 'sparse_default_4.y' using strategy 'pdr': partitions not equivalent"
    ;;
    UNKNOWN)
        echo "Could not prove equivalence of partition 'sparse_default_4.y' using strategy 'pdr': equivalence unknown"
    ;;
    TIMEOUT)
        echo "Could not prove equivalence of partition 'sparse_default_4.y' using strategy 'pdr': timeout"
    ;;
    *)
        cat sparse_default_4.y/ERROR 2> /dev/null
        echo "Execution of strategy 'pdr' on partition 'sparse_default_4.y' encountered an error."
        echo "More details can be found in '/home/jumptiger/Documents/Codex/2026-10-02/FPGA-Competition-2026-repro-v14/clean-v11/shared-tree-tests-33ryc0we/sparse_default_4/proof/strategies/sparse_default_4.y/pdr/sparse_default_4.y/logfile.txt'."
        exit 1
    ;;
esac
exit 0

